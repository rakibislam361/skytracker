<x-utils.edit-button :href="route('admin.product.status.edit', $status)" />
<x-utils.delete-button :href="route('admin.product.status.destroy', $status)" />