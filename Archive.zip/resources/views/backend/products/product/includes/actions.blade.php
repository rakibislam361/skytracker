<x-utils.edit-button :href="route('admin.product.product.edit', $product)" />
<x-utils.delete-button :href="route('admin.product.product.destroy', $product)" />