<x-utils.edit-button :href="route('admin.product.brand.edit', $brand)" />
<x-utils.delete-button :href="route('admin.product.brand.destroy', $brand)" />