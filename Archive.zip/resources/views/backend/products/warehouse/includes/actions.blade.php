<x-utils.edit-button :href="route('admin.product.warehouse.edit', $warehouse)" />
<x-utils.delete-button :href="route('admin.product.warehouse.destroy', $warehouse)" />