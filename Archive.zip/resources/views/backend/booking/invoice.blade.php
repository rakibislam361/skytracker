<!DOCTYPE html>
<html>

<head>
    <title>Generate Invoice PDF - SkytrackBD.com</title>
</head>
<style type="text/css">
    body {
        font-family: 'Roboto Condensed', sans-serif;
    }

    .m-0 {
        margin: 0px;
    }

    .p-0 {
        padding: 0px;
    }

    .pt-5 {
        padding-top: 5px;
    }

    .mt-10 {
        margin-top: 10px;
    }

    .text-center {
        text-align: center !important;
    }

    .w-100 {
        width: 100%;
    }

    .w-50 {
        width: 50%;
    }

    .w-85 {
        width: 85%;
    }

    .w-15 {
        width: 15%;
    }

    .logo img {
        width: 45px;
        height: 45px;
        padding-top: 30px;
    }

    .logo span {
        margin-left: 8px;
        top: 19px;
        position: absolute;
        font-weight: bold;
        font-size: 25px;
    }

    .gray-color {
        color: #5D5D5D;
    }

    .text-bold {
        font-weight: bold;
    }

    .border {
        border: 1px solid black;
    }

    table tr,
    th,
    td {
        border: 1px solid #d2d2d2;
        border-collapse: collapse;
        padding: 7px 8px;
    }

    table tr th {
        background: #F4F4F4;
        font-size: 15px;
    }

    table tr td {
        font-size: 13px;
    }

    table {
        border-collapse: collapse;
    }

    .box-text p {
        line-height: 10px;
    }

    .float-left {
        float: left;
    }

    .total-part {
        font-size: 16px;
        line-height: 12px;
    }

    .total-right p {
        padding-right: 20px;
    }
</style>

<body>
    <div class="head-title">
        <h1 class="text-center m-0 p-0">SkytrackBD Invoice</h1>
    </div>
    <div>
        <div>
            <p>Invoice Id - <span>INVLOCAL{{ $booking->id }}</span>
            </p>
            {{-- <p class="m-0 pt-5 text-bold w-100">Order Id - <span class="gray-color">162695CDFS</span></p>
            <p class="m-0 pt-5 text-bold w-100">Order Date - <span class="gray-color">03-06-2022</span></p> --}}
        </div>
        {{-- <div class="w-50 float-left logo mt-10">

            <img src="https://www.nicesnippets.com/image/imgpsh_fullsize.png"> <span>SkytrackBD.com</span>
        </div> --}}
        {{-- <div style="clear: both;"></div> --}}
    </div>
    {{-- <div class="table-section bill-tbl w-100 mt-10">
        <table class="table w-100 mt-10">
            <tr>
                <th class="w-50">From</th>
                <th class="w-50">To</th>
            </tr>
            <tr>
                <td>
                    <div class="box-text">
                        <p>Gujarat</p>
                        <p>360004</p>
                        <p>Near Haveli Road,</p>
                        <p>Lal Darvaja,</p>
                        <p>India</p>
                        <p>Contact : 1234567890</p>
                    </div>
                </td>
                <td>
                    <div class="box-text">
                        <p>Rajkot</p>
                        <p>360012</p>
                        <p>Hanumanji Temple,</p>
                        <p>Lati Ploat</p>
                        <p>Gujarat</p>
                        <p>Contact : 1234567890</p>
                    </div>
                </td>
            </tr>
        </table>
    </div> --}}
    {{-- <div class="table-section bill-tbl w-100 mt-10">
        <table class="table w-100 mt-10">
            <tr>
                <th class="w-50">Payment Method</th>
                <th class="w-50">Shipping Method</th>
            </tr>
            <tr>
                <td>Cash On Delivery</td>
                <td>Free Shipping - Free Shipping</td>
            </tr>
        </table>
    </div> --}}
    @php
        $cartons = $booking->cartons;
        $carton_number = [];
        $shipping_mark = [];
        $shipping_number = [];
        $actual_weight = null;
        $tracking_id = [];
        foreach ($cartons as $key => $value) {
            $carton_number = $value->carton_number;
            $shipping_mark = $value->shipping_mark;
            $shipping_number = $value->shipping_number;
            $actual_weight = $value->actual_weight;
            $tracking_id = $value->tracking_id;
        }
    @endphp
    <div class="table-responsive">
        <table class="table table-hover table-bordered mb-0 order-table table-striped">
            <thead>
                <tr>
                    <th class="align-content-center text-center">Date</th>
                    <th class="align-content-center text-center">Customer</th>
                    <th class="align-content-center text-center">Products</th>
                    <th class="align-content-center text-center">Qty</th>
                    <th class="align-content-center text-center">Price</th>
                    <th class="align-content-center text-center">Shipping Mark</th>
                    <th class="align-content-center text-center">Carton Number</th>
                    <th class="align-content-center text-center">Tracking Number</th>
                    <th class="align-content-center text-center">Weight</th>
                    <th class="align-content-center text-center">Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="align-content-center text-center">
                        {{ $booking->date ? date('d/m/Y', strtotime($booking->date)) : date('d/m/Y', strtotime($booking->created_at)) }}
                    </td>
                    <td class="align-content-center text-center">{{ $booking->user->name ?? 'N/A' }}</td>
                    <td class="align-content-center text-center">{{ $booking->othersProductName ?? 'N/A' }}</td>
                    <td class="align-content-center text-center">{{ $booking->productQuantity ?? 'N/A' }}</td>
                    <td class="align-content-center text-center">{{ $booking->productsTotalCost ?? 'N/A' }}</td>
                    <td class="align-content-center text-center">{{ $shipping_mark ?? 'N/A' }}</td>
                    <td class="align-content-center text-center">{{ $carton_number ?? 'N/A' }}</td>
                    <td class="align-content-center text-center">{{ $tracking_id ?? 'N/A' }}</td>
                    <td class="align-content-center text-center">{{ $actual_weight ?? 'N/A' }}</td>
                    <td class="align-content-center text-center">{{ $booking->amount ?? 'N/A' }}</td>
                </tr>
            <tbody>
                <tr>
                    <td colspan="10">
                        <div class="total-part">
                            <div class="total-left w-85 float-left" align="right">
                                {{-- <p>Sub Total</p> --}}
                                {{-- <p>Tax (18%)</p> --}}
                                <p>Total Amount:</p>
                            </div>
                            <div class="total-right w-15 float-left text-bold" align="right">

                                <p>{{ $booking->amount ?? 'N/A' }}</p>
                            </div>
                            <div style="clear: both;"></div>
                        </div>
                    </td>
                </tr>
        </table>
    </div>

</html>
