<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class d2dController extends Controller
{
    public function d2d(Request $request)
    {
        //
    }
}
